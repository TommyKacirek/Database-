INSERT INTO `customer_detail` (`membership_expiration`, `shelve_number`) VALUES ('2004-07-11', '60');
INSERT INTO `customer_detail` (`membership_expiration`, `shelve_number`) VALUES ('2009-04-23', '61');
INSERT INTO `customer_detail` (`membership_expiration`, `shelve_number`) VALUES ('2004-11-04', '62');
INSERT INTO `customer_detail` (`membership_expiration`, `shelve_number`) VALUES ('2012-10-02', '63');
INSERT INTO `customer_detail` (`membership_expiration`, `shelve_number`) VALUES ('2012-09-20', '64');

INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Volodar', 'Mirabalar', 'Mirabalar@seznam.cz', '202918213', '2013-01-18
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Sakaala', 'Balren', 'Balren@seznam.cz', '202918214', '1991-06-12
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Zentha', 'Wysahice', 'Wysahice@seznam.cz', '202918216', '2009-03-20
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Sihnion', 'Liabanise', 'Liabanise@seznam.cz', '202918219', '2010-12-08
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Ena', 'Davaris', 'Davaris@post.cz', '202918223', '2006-03-20
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Halflar', 'Eilmaer', 'Eilmaer@seznam.cz', '202918228', '2014-04-14
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Nyvorlas', 'Gilleth', 'Gilleth@post.cz', '202918229', '2011-06-07
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Yaereene', 'Wysatoris', 'Wysatoris@seznam.cz', '202918231', '1995-03-22
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Annallee', 'Erzeiros', 'Erzeiros@post.cz', '202918234', '1991-11-30
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Delsanra', 'Qiharice', 'Qiharice@seznam.cz', '202918238', '2009-06-21
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Anarzee', 'Wyngwyn', 'Wyngwyn@post.cz', '202918243', '2020-05-17
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Haldir', 'Ertris', 'Ertris@post.cz', '202918244', '2021-03-01
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Ildilyntra', 'Cairalei', 'Cairalei@seznam.cz', '202918246', '2013-05-02
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`) VALUES ('Hagre', 'Dordove', 'Dordove@post.cz', '202918249', '2000-08-02
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Kaylessa', 'Lucan', 'Lucan@seznam.cz', '202918253', '2011-08-07
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Hastios', 'Naetris', 'Naetris@email.cz', '202918258', '2009-07-14
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Elashor', 'Elbalar', 'Elbalar@email.cz', '202918259', '2004-05-15
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Bialaer', 'Inagella', 'Inagella@seznam.cz', '202918261', '1994-09-25
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Emmyth', 'Yingwyn', 'Yingwyn@email.cz', '202918264', '1993-12-07
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Jhaeros', 'Leojor', 'Leojor@email.cz', '202918268', '2014-11-15
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Amra', 'Olakas', 'Olakas@seznam.cz', '202918273', '2012-10-25
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Agandaur', 'Arajyre', 'Arajyre@google.com', '202918274', '2004-06-07
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Shelara', 'Fenjyre', 'Fenjyre@google.com', '202918276', '1999-07-31
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Lysanthir', 'Trawynn', 'Trawynn@seznam.cz', '202918279', '1990-12-24
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Nushala', 'Liabella', 'Liabella@google.com', '202918283', '1999-12-17
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Malon', 'Balkian', 'Balkian@seznam.cz', '202918288', '2005-10-02
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Ettrian', 'Jorieth', 'Jorieth@google.com', '202918289', '2015-01-27
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Illithor', 'Iarstina', 'Iarstina@google.com', '202918291', '2006-08-14
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Shalheira', 'Syllana', 'Syllana@seznam.cz', '202918294', '2004-03-22
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Tarathiel', 'Loraxisys', 'Loraxisys@google.com', '202918298', '2020-12-20
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Elred', 'Caicyne', 'Caicyne@seznam.cz', '202918303', '1994-04-11
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Athtar', 'Phizeiros', 'Phizeiros@email.cz', '202918304', '2003-09-11
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Drannor', 'Xyrwenys', 'Xyrwenys@email.cz', '202918306', '2008-12-24
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Illithor', 'Yinpeiros', 'Yinpeiros@email.cz', '202918309', '2007-08-13
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Aneirin', 'Ianphyra', 'Ianphyra@email.cz', '202918313', '1992-02-18
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Vulmon', 'Zinharice', 'Zinharice@email.cz', '202918318', '2009-06-12
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Syndra', 'Virhana', 'Virhana@post.cz', '202918319', '2011-05-02
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Gormar', 'Bileth', 'Bileth@post.cz', '202918321', '1999-11-10
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Alred', 'Traxisys', 'Traxisys@post.cz', '202918324', '2014-10-18
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Garynnon', 'Omazorwyn', 'Omazorwyn@post.cz', '202918328', '2015-11-12
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Almon', 'Miadithas', 'Miadithas@google.com', '202918333', '2007-01-15
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Arathorn', 'Farzumin', 'Farzumin@google.com', '202918334', '2018-06-24
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Mnementh', 'Arabalar', 'Arabalar@google.com', '202918336', '2007-06-08
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Jorildyn', 'Inadan', 'Inadan@google.com', '202918339', '1999-04-24
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Ciliren', 'Zylyarus', 'Zylyarus@google.com', '202918343', '2019-09-07
', '5');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Nhamashal', 'Lorana', 'Lorana@google.com', '202918348', '1992-02-05
', '1');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Eloimaya', 'Ianfiel', 'Ianfiel@google.com', '202918349', '1996-09-25
', '2');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Katyr', 'Helera', 'Helera@google.com', '202918351', '2017-07-19
', '3');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Aerith', 'Heiyarus', 'Heiyarus@seznam.cz', '202918354', '2021-06-09
', '4');
INSERT INTO user (`given_name`, `family_name`, `email`, `phone_number`, `born`, `customer_detail_customer_id`)  VALUES ('Elaran', 'Liluth', 'Elaran@seznam.cz', '202918358', '2022-08-14
', '5');


INSERT INTO `role` (`type`) VALUES ('employee');
INSERT INTO `role` (`type`) VALUES ('customer');
INSERT INTO `role` (`type`) VALUES ('super_customer');
INSERT INTO `role` (`type`) VALUES ('manager');
INSERT INTO `role` (`type`) VALUES ('CEO');


INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Mirabalar@seznam.cz', 'BzHpniM8W8', '4355a46b19d348dc2f57c046f8ef63d4538ebb936000f3c9ee954a27460dd865', '1');
INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Balren@seznam.cz', 'mlpiE1cYrx', '05754ebfa6628cffd8ebbbd033ee3ee75f4d4e55dd585a27e7fda7b94574ef1d', '2');
INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Wysahice@seznam.cz', 'f3wBET6IIl', '1121cfccd5913f0a63fec40a6ffd44ea64f9dc135c66634ba001d10bcf4302a2', '3');
INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Liabanise@seznam.cz', '2n8DXJS3E8', '7de1555df0c2700329e815b93b32c571c3ea54dc967b89e81ab73b9972b72d1d', '4');
INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Davaris@post.cz', 'OiXwm2BzZX', 'f0b5c2c2211c8d67ed15e75e656c7862d086e9245420892a7de62cd9ec582a06', '5');
INSERT INTO `sign_in` (`login_email`, `salt`, `passwd_hash`, `user_user_id`) VALUES ('Eilmaer@seznam.cz', '0FVD9DqTDZ', '06e9d52c1720fca412803e3b07c4b228ff113e303f4c7ab94665319d832bbfb7', '6');

INSERT INTO `borrow_type` (`type`) VALUES ('month');
INSERT INTO `borrow_type` (`type`) VALUES ('reference only');
INSERT INTO `borrow_type` (`type`) VALUES ('year');
INSERT INTO `borrow_type` (`type`) VALUES ('day');
INSERT INTO `borrow_type` (`type`) VALUES ('week');


INSERT INTO `location` (`floor`, `location`) VALUES ('3', '33 LEW');
INSERT INTO `location` (`floor`, `location`) VALUES ('5', '14 EV');
INSERT INTO `location` (`floor`, `location`) VALUES ('4', '81 D');
INSERT INTO `location` (`floor`, `location`) VALUES ('1', '5 PLT');
INSERT INTO `location` (`floor`, `location`) VALUES ('2', '9 F');

INSERT INTO `lang_name` (`name`) VALUES ('Čeština');
INSERT INTO `lang_name` (`name`) VALUES ('Angličtina');
INSERT INTO `lang_name` (`name`) VALUES ('Němčina');
INSERT INTO `lang_name` (`name`) VALUES ('Polština');¨
INSERT INTO `lang_name` (`name`) VALUES ('Ruština');

INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Albert', 'Camus', '1913', '1960', '1');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Marcel', 'Proust', '1871', '1922', '2');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Franz', 'Kafka', '1883', '1924', '3');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Antoine', 'de Saint-Exupéry', '1900', '1944', '4');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('André', 'Malraux', '1901', '1976', '5');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Louis-Ferdinand', 'Céline', '1894', '1961', '6');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('John', 'Steinbeck', '1902', '1968', '7');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Ernest', 'Hemingway', '1899', '1961', '8');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Alain-Fournier', '', '1886', '1914', '9');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Boris', 'Vian', '1908', '1986', '10');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Simone', 'de Beauvoir', '1906', '1989', '11');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Samuel', 'Beckett', '1905', '1980', '12');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jean-Paul', 'Sartre', '1905', '1980', '13');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Umberto', 'Eco', '1932', '2016', '14');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Alexandr', 'Solženicyn', '1913', '1960', '15');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jacques', 'Prévert', '1871', '1922', '16');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Guillaume', 'Apollinaire', '1883', '1924', '17');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Hergé', '', '1900', '1944', '18');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Anne', 'Franková', '1901', '1976', '19');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Claude', 'Lévi-Strauss', '1894', '1961', '20');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Aldous', 'Huxley', '1902', '1968', '21');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('George', 'Orwell', '1899', '1961', '22');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('René', 'Goscinny', '1886', '1914', '23');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Eugène', 'Ionesco', '1908', '1986', '24');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Sigmund', 'Freud', '1906', '1989', '25');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Marguerite', 'Yourcenarová', '1905', '1980', '26');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Vladimir', 'Nabokov', '1905', '1980', '27');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('James', 'Joyce', '1932', '2016', '28');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Dino', 'Buzzati', '1913', '1960', '29');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('André', 'Gide', '1871', '1922', '30');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jean', 'Giono', '1883', '1924', '31');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Albert', 'Cohen', '1900', '1944', '32');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Gabriel', 'Lawrence', '1901', '1976', '33');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('William', 'Faulkner', '1894', '1961', '34');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('François', 'Mauriac', '1902', '1968', '35');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Raymond', 'Queneau', '1899', '1961', '36');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Stefan', 'Zweig', '1886', '1914', '37');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Margaret', 'Mitchellová', '1908', '1986', '38');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('David', 'Lawrence', '1906', '1989', '39');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Thomas', 'Mann', '1905', '1980', '40');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Françoise', 'Saganová', '1905', '1980', '41');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Vercors', '', '1932', '2016', '42');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Georges', 'Perec', '1913', '1960', '43');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Arthur', 'Doyle', '1871', '1922', '44');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Georges', 'Bernanos', '1883', '1924', '45');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Francis', 'Fitzgerald', '1900', '1944', '46');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Milan', 'Kundera', '1901', '1976', '47');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Alberto', 'Moravia', '1894', '1961', '48');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Agatha', 'Christie', '1902', '1968', '49');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('André', 'Breton', '1899', '1961', '50');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Louis', 'Aragon', '1886', '1914', '51');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Paul', 'Claudel', '1908', '1986', '52');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Luigi', 'Pirandello', '1906', '1989', '53');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Bertolt', 'Brecht', '1905', '1980', '54');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Michel', 'Tournier', '1905', '1980', '55');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Herbert', 'Wells', '1932', '2016', '56');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Primo', 'Levi', '1913', '1960', '57');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('John', '', '1871', '1922', '58');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Colette', '', '1883', '1924', '59');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Paul', 'Éluard', '1900', '1944', '60');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jack', 'London', '1901', '1976', '61');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Hugo', 'Pratt', '1894', '1961', '62');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Roland', 'Barthes', '1902', '1968', '63');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Heinrich', 'Böll', '1899', '1961', '64');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Julien', 'Gracq', '1886', '1914', '65');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Michel', 'Foucault', '1908', '1986', '66');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jack', 'Kerouac', '1906', '1989', '67');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Selma', 'Lagerlöfová', '1905', '1980', '68');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Virginia', 'Woolfová', '1905', '1980', '69');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Ray', 'Bradbury', '1932', '2016', '70');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Marguerite', 'Durasová', '1913', '1960', '71');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jean-Marie', '', '1871', '1922', '72');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Nathalie', 'Sarrautová', '1883', '1924', '73');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jules', 'Renard', '1900', '1944', '74');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Joseph', 'Conrad', '1901', '1976', '75');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jacques', 'Lacan', '1894', '1961', '76');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Antonin', 'Artaud', '1902', '1968', '77');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('John', 'Passos', '1899', '1961', '78');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jorge', 'Borges', '1886', '1914', '79');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Blaise', 'Cendrars', '1908', '1986', '80');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Ismail', 'Kadare', '1906', '1989', '81');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('William', 'Styron', '1905', '1980', '82');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Federico', 'Lorca', '1905', '1980', '83');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Georges', 'Simenon', '1932', '2016', '84');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Jean', 'Genet', '1913', '1960', '85');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Robert', 'Musil', '1871', '1922', '86');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('René', 'Char', '1883', '1924', '87');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('J.', 'Salinger', '1900', '1944', '88');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('James', 'Chase', '1901', '1976', '89');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Edgar', 'Jacobs', '1894', '1961', '90');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Rainer', 'Rilke', '1902', '1968', '91');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Michel', 'Butor', '1899', '1961', '92');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Hannah', 'Arendtová', '1886', '1914', '93');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Michail', 'Bulgakov', '1908', '1986', '94');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Henry', 'Miller', '1906', '1989', '95');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Raymond', 'Chandler', '1905', '1980', '96');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Saint-John', 'Perse', '1905', '1980', '97');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('André', 'Franquin', '1932', '2016', '98');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Malcolm', 'Lowry', '1883', '1924', '99');
INSERT INTO `author` (`given_name`, `family_name`, `born`, `died`, `popularity_rank`) VALUES ('Salman', 'Rushdie', '1900', '1944', '100');

INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"The Stranger', '1942', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Outsider"', '1942', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"In Search of Lost Time', '1913', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Remembrance of Things Past"', '1913', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Trial', '1925', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Little Prince', '1943', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Mans Fate', '1933', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Journey to the End of the Night', '1932', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Grapes of Wrath', '1939', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('For Whom the Bell Tolls', '1940', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Le Grand Meaulnes', '1913', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Froth on the Daydream', '1947', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Second Sex', '1949', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Waiting for Godot', '1952', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Being and Nothingness', '1943', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Name of the Rose', '1980', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Gulag Archipelago', '1973', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Paroles', '1946', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Alcools', '1913', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Blue Lotus', '1936', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Diary of a Young Girl', '1947', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Tristes Tropiques', '1955', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Brave New World', '1932', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Nineteen EightyFour', '1949', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Asterix the Gaul', '1959', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Bald Soprano', '1952', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Three Essays on the Theory of Sexuality', '1905', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"The Abyss', '1968', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Zeno of Bruges"', '1968', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Lolita', '1955', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Ulysses', '1922', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Tartar Steppe', '1940', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Counterfeiters', '1925', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Horseman on the Roof', '1951', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Belle du Seigneur', '1968', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('One Hundred Years of Solitude', '1967', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Sound and the Fury', '1929', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Thérèse Desqueyroux', '1927', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Zazie in the Metro', '1959', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Confusion of Feelings', '1927', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Gone with the Wind', '1936', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Lady Chatterleys Lover', '1928', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Magic Mountain', '1924', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Bonjour Tristesse', '1954', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Le Silence de la mer', '1942', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Life: A Users Manual', '1978', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Hound of the Baskervilles', '1901', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Under the Sun of Satan', '1926', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Great Gatsby', '1925', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Joke', '1967', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Contempt A Ghost at Noon', '1954', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Murder of Roger Ackroyd', '1926', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Nadja', '1928', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Aurélien', '1944', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Satin Slipper', '1929', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Six Characters in Search of an Author', '1921', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Resistible Rise of Arturo Ui', '1941', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Friday', '1967', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The War of the Worlds', '1898', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"If This Is a Man', '1947', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES (' Se questo è un uomo, Survival in Auschwitz"', '1947', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Lord of the Rings', '1954', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Tendrils of the Vine', '1908', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Capital of Pain', '1926', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Martin Eden', '1909', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Ballad of the Salty Sea', '1967', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Writing Degree Zero', '1953', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Lost Honour of Katharina Blum', '1974', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Opposing Shore', '1951', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Order of Things', '1966', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('On the Road', '1957', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Wonderful Adventures of Nils', '1906', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('A Room of Ones Own', '1929', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Martian Chronicles', '1950', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Ravishing of Lol Stein', '1964', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Interrogation', '1963', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Tropisms', '1939', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Journal, 1887–1910', '1925', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Lord Jim', '1900', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Écrits', '1966', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Theatre and Its Double', '1938', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Manhattan Transfer', '1925', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Ficciones', '1944', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Moravagine', '1926', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The General of the Dead Army', '1963', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Sophies Choice', '1979', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Gypsy Ballads', '1928', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Strange Case of Peter the Lett', '1931', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Our Lady of the Flowers', '1944', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Man Without Qualities', '1930', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Furor and Mystery', '1948', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Catcher in the Rye', '1951', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('No Orchids For Miss Blandish', '1939', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Blake and Mortimer', '1950', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Notebooks of Malte Laurids Brigge', '1910', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Second Thoughts', '1957', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"The Origins of Totalitarianism', '1951', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Burden of Our Time"', '1951', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Master and Margarita', '1967', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Rosy Crucifixion', '1949', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('The Big Sleep', '1939', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Amers', '1957', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('"Gaston', '2014', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Gomer Goof"', '1957', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Under the Volcano', '1947', '0', '0');
INSERT INTO `title` (`title_name`, `publication_year`, `availability_present`, `availability_absent`) VALUES ('Midnights Children', '1981', '0', '0');


INSERT INTO `copy` (`type_of_borrow`, `release_year`, `borrowed`, `lang_id`, `no_of_pages`, `height`, `depth`, `width`, `stock_location_mark`, `borrow_type_borrow_type_id`, `location_location_id`, `title_title_id`, `lang_name_lang_name_id`) VALUES ('2', '2005', '0', '1', '200', '25', '3', '20', '1AE45GF', '1', '1', '1', '1');
INSERT INTO `copy` (`type_of_borrow`, `release_year`, `borrowed`, `lang_id`, `no_of_pages`, `height`, `depth`, `width`, `stock_location_mark`, `borrow_type_borrow_type_id`, `location_location_id`, `title_title_id`, `lang_name_lang_name_id`) VALUES ('1', '2000', '0', '2', '300', '20', '2.5', '15', '4DA89HH', '1', '2','2','2');
INSERT INTO `copy` (`type_of_borrow`, `release_year`, `borrowed`, `lang_id`, `no_of_pages`, `height`, `depth`, `width`, `stock_location_mark`, `borrow_type_borrow_type_id`, `location_location_id`, `title_title_id`, `lang_name_lang_name_id`) VALUES ('1', '1955', '0', '3', '400', '15', '2', '10', 'JK402QE', '1','3','3','3');
INSERT INTO `copy` (`type_of_borrow`, `release_year`, `borrowed`, `lang_id`, `no_of_pages`, `height`, `depth`, `width`, `stock_location_mark`, `borrow_type_borrow_type_id`, `location_location_id`, `title_title_id`, `lang_name_lang_name_id`) VALUES ('2', '1999', '0', '4', '500', '10', '1.5', '5', 'ZUY12LU', '1','4','4','4');
INSERT INTO `copy` (`type_of_borrow`, `release_year`, `borrowed`, `lang_id`, `no_of_pages`, `height`, `depth`, `width`, `stock_location_mark`, `borrow_type_borrow_type_id`, `location_location_id`, `title_title_id`, `lang_name_lang_name_id`) VALUES ('1', '1993', '0', '4', '666', '5', '1', '5', '1POKA14', '1','5','5','4');

INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2002-08-03', '2002-09-03', '0', '1', '1');
INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2014-11-13', '2014-12-13', '0', '2', '2');
INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2005-06-27', '2005-07-27', '0', '3', '3');
INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2013-03-19', '2013-04-19', '0', '4', '4');
INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2009-05-16', '2009-06-16', '0', '5', '5');
INSERT INTO `borrow` (`release_date`, `due_date`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('1997-09-05', '1997-10-05', '0', '6', '1');


 
INSERT INTO `borrow_archive` (`release_date`, `date_of_return`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2002-11-29', '2002-12-29', '0', '1', '1');
INSERT INTO `borrow_archive` (`release_date`, `date_of_return`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2001-01-20', '2001-02-20', '0', '2', '2');
INSERT INTO `borrow_archive` (`release_date`, `date_of_return`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('1990-07-04', '1990-08-04', '0', '3', '3');
INSERT INTO `borrow_archive` (`release_date`, `date_of_return`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2003-08-19', '2003-09-19', '0', '4', '4');
INSERT INTO `borrow_archive` (`release_date`, `date_of_return`, `extensions`, `user_user_id`, `copy_copy_id`) VALUES ('2020-10-16', '2020-11-16', '0', '5', '5');


INSERT INTO `genre` (`genre`) VALUES ('finanční krize 2001/2010 Spojené státy americké');
INSERT INTO `genre` (`genre`) VALUES ('hospodářská politika 2001/2010 Spojené státy americké');
INSERT INTO `genre` (`genre`) VALUES ('Spojené státy americké hospodářské poměry 2001/2010');
INSERT INTO `genre` (`genre`) VALUES ('studie');
INSERT INTO `genre` (`genre`) VALUES ('finanční krize');

