# BDS-projekt

## Design decisions

Database has two main parts: user part and book part. The user part contains only the most basic information unique to each person. The user is given a role that separates privileges, currently there is only one role that is “customer”. Each customer has table for signing into the system. 

Book part is the larger halve of this project. The tables themselves are described in latter part of this document, but the main idea is that every title is taken as it’s separate entity. Then for each title there are tables describing copies the library has to offer. The book are also divided into two types, those are: month and reference only. Reference only means that customer can order the book and have assurance that it’ll be available for him or her, but the books isn’t meant to be taken away from the library property.

![ERD diagram](./final_picture.png "ERD diagram")

## 3rd normal form
The design is third normal form because all the attributes cannot be divided further (atomicity). 
There are no repeated attributes except for ids that are used to organize the whole database.  
All the attributes are unique to the table and if not they’ve been given a foreign key and moved to a separate table.

## Functional and non-functional requirements
### functional
-	After borrowed book is returned the borrow information is put into borrow archive table and borrow table is deleted.
-	After an order is made it’s information is put into order queue and after the book is picked up borrow table is created.
-	Data should have a backup in our system.
### non-functional
-	3 days before borrow is due customer is sent an email informing him or her and customer is given option to extend the borrow.
-	Customer should have the option to pick up the order within two hours - Customer has 5 days to pick up his or her order. 
-	Data backup should be updated daily.

